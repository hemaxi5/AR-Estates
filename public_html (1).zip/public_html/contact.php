<!doctype html>
<html lang="en">
    

<head>
        <!-- :: Required Meta Tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="ONS Industries">
        <meta name="keywords" content="ONS Industries">

        <!-- :: Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- :: Favicon -->
        <link rel="icon" type="image/png" href="assets/images/favicon.png">

        <!-- :: Title -->
        <title>Contact Us | ONS Industries</title>

        <!-- :: Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&amp;family=Heebo:wght@400;500;600;700&amp;display=swap">

        <!-- :: Fontawesome -->
        <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">

        <!-- :: Flaticon -->
        <link rel="stylesheet" href="assets/fonts/flaticon/style.css">

        <!-- :: Animate -->
        <link rel="stylesheet" href="assets/css/animate.css">
        
        <!-- :: Owl Carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        
        <!-- :: Lity -->
        <link rel="stylesheet" href="assets/css/lity.min.css">
        
        <!-- :: Nice Select CSS -->
        <link rel="stylesheet" href="assets/css/nice-select.css">
        
        <!-- :: Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/magnific-popup.css">

        <!-- :: Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- :: Style Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <!--[if lt IE 9]>
                <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
                <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
            <![endif]-->
    </head>

    <body>

 <!------------
        <div class="loading">
            <div class="loading-box">
                <div class="lds-roller">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
		-------------->
        
	<?php include('inc/header.php');?>  
        

 
        <!-- :: Breadcrumb Header -->
        <section class="breadcrumb-header style-2" id="page" style="background-image: url(img/banner/banner-chemical-industry.jpg)">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="banner">
                            <h1>contact US</h1>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><i class="fas fa-angle-right"></i></li>
                                <li>contact US</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		
	
		                         <h6><b>Our Manufacturing Unit </b></h6>
		                        
		                    </div>
		                    
		                        <p><h6> Khasra No . 586- Kandela Industrial Area - Kandela -Shamli -247774 ( UP)				
</h6></p>
                                
		                         <h6> <b>Our External Manufacturing -Unit
</b> </h6>
		                        
		                    </div>
		                    
		                        
		                        <h6> ONS Industries Pvt. Ltd. operates three external manufacturing units: two are located in Uttar Pradesh, and one is in Gujarat. Each unit adheres to ONS Industries' strict guidelines and compliance standards to ensure consistent quality and regulatory compliance.					
</h6>
						</p>
                                   
                                
                                </div> 
		                        
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
		  
		    
		                         <h6> <b>Our Corporate Office</b> </h6>
		                        
		                    </div>
		                    
		                        <p>
		                        
		                      <h6>   Plot no 49,Evergreen Industrial Park 2, Hasanpur Masoori,Bagpat,Uttar Pradesh <br>Pin Code:250101</h6>
						</p>
						 <h6> <b>Our Central  R& D Centre
</b> </h6>
		                        
		                    </div>
		                    
		                        <p>
		                        
		                      <h6>   Plot No . 48, Evergreen Industrial Park -2, Hasanpur , Masoori , Bagpat -250101 ( UP )					
( The Central R&D unit at ONS Industries Pvt. Ltd. is currently under development and will soon be operational. This facility is expected to play a critical role in enhancing research capabilities, likely supporting innovations in Specialty Chemicals, Agrochemicals, and API Intermediates.)					
</h6>
						</p>
						 <h6> <b>Our Registered Office
</b> </h6>
		                        
		                    </div>
		                    
		                        <p>
		                        
		                      <h6>   A-24/12 , Awas Vikas , Sec-5, Sapna -1 ,Loni , Ghaziabad -201102				
Telephone : 91-9315926696  Email : Info@onsindustries.com  Visit Us : www.onsindustries.com					
</h6>
						</p>
						
                                   
                              
                                </div> 
		                        
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
		</section>
		<!-- :: contact us -->
		<div class="contact-us py-100">
            <div class="container">
                
                <div class="row">
                    <div class="col-lg-6">
                        <!-- :: Map -->
                        <div class="map-box">
                            <iframe frameborder="0" scrolling="no" marginheight="0" marginwidth="0" id="gmap_canvas" src="https://maps.google.com/maps?width=520&amp;height=400&amp;hl=en&amp;q=Kandela%20Industrial%20Area%20+()&amp;t=&amp;z=12&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe> <a href='https://mapswebsite.org/'>visit website</a> <script type='text/javascript' src='https://embedmaps.com/google-maps-authorization/script.js?id=0896eb4ab60b0fb1479a36453a9d5373695a9a37'></script>
                        </div>
                    </div>
                    <div class="col-lg-6">
						<div class="add-comments">
							<form class="inner-add-comments">
								<div class="row">
									<div class="col-md-6 inner-add-comments-box">
										<input type="text" placeholder="Name" required>
									</div>
									<div class="col-md-6 inner-add-comments-box">
										<input type="Email" placeholder="Email" required>
									</div>
									<div class="col-md-12 inner-add-comments-box">
										<input type="text" placeholder="Website" required>
									</div>
									<div class="col-md-12 inner-add-comments-box">
										<textarea placeholder="Your Message Here " rows="5"  cols="50" required></textarea>
									</div>
									<div class="col-md-12 inner-add-comments-box last">
										<button class="btn-1 btn-3 submit" type="submit"><span>Submit</span></button>
									</div>
								</div>
							</form>
						</div>
                    </div>
                </div>
            </div>
        </div>
		
  
  	<?php include('inc/footer.php');?> 
        
        <!-- :: JavaScript Files -->
        <!-- :: jQuery JS -->
        <script src="assets/js/jquery-3.6.0.min.js"></script>

        <!-- :: Bootstrap JS Bundle With Popper JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        
        <!-- :: Owl Carousel JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        
        <!-- :: Lity -->
        <script src="assets/js/lity.min.js"></script>
        
        <!-- :: Nice Select -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        
        <!-- :: Waypoints -->
        <script src="assets/js/jquery.waypoints.min.js"></script>

        <!-- :: CounterUp -->
        <script src="assets/js/jquery.counterup.min.js"></script>
        
        <!-- :: Magnific Popup -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		
		<!-- :: MixitUp -->
        <script src="assets/js/mixitup.min.js"></script>
        
        <!-- :: Main JS -->
        <script src="assets/js/main.js"></script>
    </body>


</html>