<!doctype html>
<html lang="en">
    

<head>
        <!-- :: Required Meta Tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="ONS Industries">
        <meta name="keywords" content="ONS Industries">

        <!-- :: Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- :: Favicon -->
        <link rel="icon" type="image/png" href="assets/images/favicon.png">

        <!-- :: Title -->
        <title>Product | ONS Industries</title>

        <!-- :: Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&amp;family=Heebo:wght@400;500;600;700&amp;display=swap">

        <!-- :: Fontawesome -->
        <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">

        <!-- :: Flaticon -->
        <link rel="stylesheet" href="assets/fonts/flaticon/style.css">

        <!-- :: Animate -->
        <link rel="stylesheet" href="assets/css/animate.css">
        
        <!-- :: Owl Carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        
        <!-- :: Lity -->
        <link rel="stylesheet" href="assets/css/lity.min.css">
        
        <!-- :: Nice Select CSS -->
        <link rel="stylesheet" href="assets/css/nice-select.css">
        
        <!-- :: Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/magnific-popup.css">

        <!-- :: Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- :: Style Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <!--[if lt IE 9]>
                <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
                <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
            <![endif]-->
    </head>

    <body>

 <!------------
        <div class="loading">
            <div class="loading-box">
                <div class="lds-roller">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
		-------------->
        
	<?php include('inc/header.php');?>  
        

 
        <!-- :: Breadcrumb Header -->
        <section class="breadcrumb-header style-2" id="page" style="background-image: url(img/banner/banner-chemical-industry.jpg)">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="banner">
                            <h1>Product</h1>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><i class="fas fa-angle-right"></i></li>
                                <li>Product</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		
<div class="single-services py-100-70">
			<div class="container">
				<div class="row">
					<div class="col-lg-4">
						<?php include("inc/sidebar.php") ?>
					</div>
					<div class="col-lg-8">
						<div class="chemical-list">
		<table class="chem-table" cellspacing="0" style="border-collapse:collapse; width:999px">
	<tbody>
		<tr class="tabel-h">
			<td rowspan="2" ><strong>Sr.No</strong></td>
			<td rowspan="2" ><strong>Product Name</strong></td>
			<td rowspan="2" ><strong>CAS No</strong></td>
			<td colspan="2" ><strong>Specification</strong></td>
			<td rowspan="2" ><strong>Production Capacity (MT)</strong></td>
			<td rowspan="2" ><strong>Use</strong></td>
		</tr>
		<tr class="tabel-h">
			<td ><strong>Test</strong></td>
			<td ><strong>Specification limit</strong></td>
		</tr>
		<tr>
			<td rowspan="2" >4</td>
		
			<td rowspan="2" >Phenyl hydrazine&nbsp;</td>
				
		
			<td rowspan="2" >100-63.-0</td>
			<td >Appearance</td>
			<td >White to Yellow and White to Orange and Yellow White to Brown</td>
			<td rowspan="2" >15.00 MT&nbsp;</td>
			<td rowspan="2" >Phenyl hydrazine is used&nbsp;to prepare indoles by the Fischer indole synthesis, which are intermediates in the synthesis of various dyes and pharmaceuticals. Phenyl hydrazine is used to form phenylhydrazones of natural mixtures of simple sugars in order to render the differing sugars easily separable from each other.</td>
		</tr>
		<tr>
			<td >Purity&nbsp;</td>
			<td >99.00%</td>
		</tr>
		
		
		
		
		
		
		
		
		
	</tbody>
</table>
		</div>
					</div>
				</div>
			</div>
		</div>


 
		

  
  	<?php include('inc/footer.php');?> 
        
        <!-- :: JavaScript Files -->
        <!-- :: jQuery JS -->
        <script src="assets/js/jquery-3.6.0.min.js"></script>

        <!-- :: Bootstrap JS Bundle With Popper JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        
        <!-- :: Owl Carousel JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        
        <!-- :: Lity -->
        <script src="assets/js/lity.min.js"></script>
        
        <!-- :: Nice Select -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        
        <!-- :: Waypoints -->
        <script src="assets/js/jquery.waypoints.min.js"></script>

        <!-- :: CounterUp -->
        <script src="assets/js/jquery.counterup.min.js"></script>
        
        <!-- :: Magnific Popup -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		
		<!-- :: MixitUp -->
        <script src="assets/js/mixitup.min.js"></script>
        
        <!-- :: Main JS -->
        <script src="assets/js/main.js"></script>
    </body>


</html>