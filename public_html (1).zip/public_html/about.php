<!doctype html>
<html lang="en">
    

<head>
        <!-- :: Required Meta Tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="ONS Industries">
        <meta name="keywords" content="ONS Industries">

        <!-- :: Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- :: Favicon -->
        <link rel="icon" type="image/png" href="assets/images/favicon.png">

        <!-- :: Title -->
        <title>About Us | ONS Industries</title>

        <!-- :: Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&amp;family=Heebo:wght@400;500;600;700&amp;display=swap">

        <!-- :: Fontawesome -->
        <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">

        <!-- :: Flaticon -->
        <link rel="stylesheet" href="assets/fonts/flaticon/style.css">

        <!-- :: Animate -->
        <link rel="stylesheet" href="assets/css/animate.css">
        
        <!-- :: Owl Carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        
        <!-- :: Lity -->
        <link rel="stylesheet" href="assets/css/lity.min.css">
        
        <!-- :: Nice Select CSS -->
        <link rel="stylesheet" href="assets/css/nice-select.css">
        
        <!-- :: Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/magnific-popup.css">

        <!-- :: Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- :: Style Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <!--[if lt IE 9]>
                <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
                <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
            <![endif]-->
    </head>

    <body>

 <!------------
        <div class="loading">
            <div class="loading-box">
                <div class="lds-roller">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
		-------------->
        
	<?php include('inc/header.php');?>  
        

 
        <!-- :: Breadcrumb Header -->
        <section class="breadcrumb-header style-2" id="page" style="background-image: url(img/banner/banner-chemical-industry.jpg)">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="banner">
                            <h1>About Us</h1>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><i class="fas fa-angle-right"></i></li>
                                <li>About Us</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		



 <!-- :: Team -->
       
		<section class="about-us home-3 py-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="about-us-img-box">
                            <div class="img-box" style="background-image: url(img/home-about.jpg)"></div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-us-text-box">
                            <div class="sec-title home-3">
                                <h2>About Us</h2>
                                <h3>Welcome To ONS Industries Pvt Ltd</h3>
                                <p class="sec-explain ">ONS Industries is a research-based specialty ingredients company. ONS Industries is an Innovative Solutions provider serving, Pharmaceutical, Nutrition, Agrochemical, Consumer and Industrial customers with our customized products and solutions that are innovative, cost-effective and conforming to excellent quality standards. With our customers at the heart of everything we do, our focus is to manufacture products with sustainability using our process technology through greater R&amp;D and engineering capabilities to deliver values for our customers for their complex and multi-step synthesis projects.</p>
                            </div>
							
							
                        </div>
                    </div>
                </div>
            </div>
        </section>
		
		<section class="missions teams">
		<div class="container">
		<div class="row justify-content-center">
		<div class="col-lg-12 ">
		<div class="text-center">
		<h3>Mission and Vision</h3>
		</div>
		</div>
		
		<div class="col-lg-10">
		<div class="vission-cards">
		<h4>Mission</h4>
		<ul>
		<li> Manufacture superior quality products that lead to enhance customer satisfaction.</li>
		<li> Harness growth by offering value to our customers through our superior products</li>
		<li> Create long term mutually beneficial business associations</li>
		<li> Strive to carve a niche with cost efficiencies, develop stronger customer relationships and build competitive advantages.</li>
		</ul>
		</div>
		</div>
		<div class="col-lg-10">
		<div class="vission-cards">
		<h4>Vision</h4>
		<ul>
		<li> Through adaptive improvement, we will continue to be a leader in the manufacturing of speciality chemicals. We will advance the speciality intermediate business through our innovation, hard work and responsible care initiatives.</li>
		</ul>
		</div>
		</div>
		</div>
		</div>
		</section>



  
  	<?php include('inc/footer.php');?> 
        
        <!-- :: JavaScript Files -->
        <!-- :: jQuery JS -->
        <script src="assets/js/jquery-3.6.0.min.js"></script>

        <!-- :: Bootstrap JS Bundle With Popper JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        
        <!-- :: Owl Carousel JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        
        <!-- :: Lity -->
        <script src="assets/js/lity.min.js"></script>
        
        <!-- :: Nice Select -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        
        <!-- :: Waypoints -->
        <script src="assets/js/jquery.waypoints.min.js"></script>

        <!-- :: CounterUp -->
        <script src="assets/js/jquery.counterup.min.js"></script>
        
        <!-- :: Magnific Popup -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		
		<!-- :: MixitUp -->
        <script src="assets/js/mixitup.min.js"></script>
        
        <!-- :: Main JS -->
        <script src="assets/js/main.js"></script>
    </body>


</html>