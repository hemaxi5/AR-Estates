<!doctype html>
<html lang="en">
    

<head>
        <!-- :: Required Meta Tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="ONS Industries">
        <meta name="keywords" content="ONS Industries">

        <!-- :: Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- :: Favicon -->
        <link rel="icon" type="image/png" href="assets/images/favicon.png">

        <!-- :: Title -->
        <title>Manufacturing block overview | ONS Industries</title>

        <!-- :: Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&amp;family=Heebo:wght@400;500;600;700&amp;display=swap">

        <!-- :: Fontawesome -->
        <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">

        <!-- :: Flaticon -->
        <link rel="stylesheet" href="assets/fonts/flaticon/style.css">

        <!-- :: Animate -->
        <link rel="stylesheet" href="assets/css/animate.css">
        
        <!-- :: Owl Carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        
        <!-- :: Lity -->
        <link rel="stylesheet" href="assets/css/lity.min.css">
        
        <!-- :: Nice Select CSS -->
        <link rel="stylesheet" href="assets/css/nice-select.css">
        
        <!-- :: Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/magnific-popup.css">

        <!-- :: Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- :: Style Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <!--[if lt IE 9]>
                <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
                <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
            <![endif]-->
    </head>

    <body>

 <!------------
        <div class="loading">
            <div class="loading-box">
                <div class="lds-roller">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
		-------------->
        
	<?php include('inc/header.php');?>  
        

 
        <!-- :: Breadcrumb Header -->
        <section class="breadcrumb-header style-2" id="page" style="background-image: url(img/banner/banner-chemical-industry.jpg)">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="banner">
                            <h1>Manufacturing block overview</h1>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><i class="fas fa-angle-right"></i></li>
                                <li>Manufacturing block overview</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		



 <!-- :: Team -->
      
		<!-----Fine Ingredients------->
		<section class="missions teams" id="special">
		<div class="container">
		<div class="row justify-content-center">
		<div class="col-lg-12 ">
		<div class="text-center">
		<h3></h3>
		</div>
		</div>
		<div class="col-lg-10">
		<div class="chemical-list">
		<table class="chem-table">
		<!---------------->
		<thead>
		<tr>
		<th>Sr.No.</th>
		<th>Equipment</th>
		<th>Nos</th>
		<th>Capacity</th>
		</tr>
		</thead>
		<!---------------->
		<!---------------->
		<tbody>
		<tr>
		<td>1.</td>
		<td>Glass Lined Reactor</td>
		<td>1</td>
		<td>5KL</td>
		</tr>
		
		<tr>
		<td>2.</td>
		<td>Glass Lined Reactor</td>
		<td>1</td>
		<td>6KL</td>
		</tr>
		
		<tr>
		<td>3.</td>
		<td>SS Reactor</td>
		<td>1</td>
		<td>6KL(Proposed)</td>
		</tr>
		
		<tr>
		<td>4.</td>
		<td>SS Reactor</td>
		<td>1</td>
		<td>5KL(Proposed)</td>
		</tr>
		
		<tr>
		<td>5.</td>
		<td>SS 316 Centrifuge</td>
		<td>2</td>
		<td>48"</td>
		</tr>
		
		<tr>
		<td>6.</td>
		<td>SS 316 Tray Dryer</td>
		<td>1</td>
		<td>48 Trays</td>
		</tr>
		

		<tr>
		<td>7.</td>
		<td>SS RCVD</td>
		<td>1</td>
		<td>1KL</td>
		</tr>
		
		<tr>
		<td>8.</td>
		<td>SS 316 Sparkler Filter</td>
		<td>1</td>
		<td>18" 24 Plates</td>
		</tr>
		

		<tr>
		<td>9.</td>
		<td>Multi Miller</td>
		<td>1</td>
		<td>200 Kg</td>
		</tr>
		
		<tr>
		<td>10.</td>
		<td>Shifter</td>
		<td>1</td>
		<td>30"</td>
		</tr>
		
		<tr>
		<td>11.</td>
		<td>Cooling Tower</td>
		<td>1</td>
		<td>200 TR</td>
		</tr>
		
		<tr>
		<td>12.</td>
		<td>Chilling Plant(-10°C)</td>
		<td>1</td>
		<td>30 TR</td>
		</tr>
		
		<tr>
		<td>13.</td>
		<td>Nitrogen Plant</td>
		<td>1</td>
		<td>100 Nm3/Hr (Proposed)</td>
		</tr>
		
		<tr>
		<td>14.</td>
		<td>Boiler</td>
		<td>1</td>
		<td>600 Hg/Hr</td>
		</tr>
		
		</tbody>
		<!---------------->
		</table>
		</div>
		</div>
		
		</div>
		</div>
		</section>
		



  
  	<?php include('inc/footer.php');?> 
        
        <!-- :: JavaScript Files -->
        <!-- :: jQuery JS -->
        <script src="assets/js/jquery-3.6.0.min.js"></script>

        <!-- :: Bootstrap JS Bundle With Popper JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        
        <!-- :: Owl Carousel JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        
        <!-- :: Lity -->
        <script src="assets/js/lity.min.js"></script>
        
        <!-- :: Nice Select -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        
        <!-- :: Waypoints -->
        <script src="assets/js/jquery.waypoints.min.js"></script>

        <!-- :: CounterUp -->
        <script src="assets/js/jquery.counterup.min.js"></script>
        
        <!-- :: Magnific Popup -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		
		<!-- :: MixitUp -->
        <script src="assets/js/mixitup.min.js"></script>
        
        <!-- :: Main JS -->
        <script src="assets/js/main.js"></script>
    </body>


</html>