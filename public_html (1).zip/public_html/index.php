<!doctype html>
<html lang="en">
    

<head>
        <!-- :: Required Meta Tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="ONS Industries pvt ltd">
        <meta name="keywords" content="ONS Industries pvt ltd">

        <!-- :: Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- :: Favicon -->
        <link rel="icon" type="image/png" href="assets/images/favicon.png">

        <!-- :: Title -->
        <title>Home | ONS Industries pvt ltd</title>

        <!-- :: Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&amp;family=Heebo:wght@400;500;600;700&amp;display=swap">

        <!-- :: Fontawesome -->
        <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">

        <!-- :: Flaticon -->
        <link rel="stylesheet" href="assets/fonts/flaticon/style.css">

        <!-- :: Animate -->
        <link rel="stylesheet" href="assets/css/animate.css">
        
        <!-- :: Owl Carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        
        <!-- :: Lity -->
        <link rel="stylesheet" href="assets/css/lity.min.css">
        
        <!-- :: Nice Select CSS -->
        <link rel="stylesheet" href="assets/css/nice-select.css">
        
        <!-- :: Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/magnific-popup.css">

        <!-- :: Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- :: Style Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <!--[if lt IE 9]>
                <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
                <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
            <![endif]-->
    </head>
    <body>
        <!------------
        <div class="loading">
            <div class="loading-box">
                <div class="lds-roller">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
		-------------->
        
       
	<?php include('inc/header.php');?>   
	   
	   
        <section class="header home-2" id="page">
            <div class="header-carousel owl-carousel owl-theme">
                <div class="sec-hero display-table">
                    <img src="img/banner/banner-chemical-industry.jpg">
					
					<div class="table-cell">
                        <div class="overlay"></div>
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-8">
                                    <div class="banner">
                                        <h1 class="handline">Welcome to ONS Industries pvt ltd <br><br>(ISO Certified 9001-2015)<br><br>
                                        (GMP Certified Company)</h1>
                                         <p class="about-website">ONS Industries pvt ltd Is A Research-Based Specialty Ingredients Company. ONS Industries pvt ltd Is An Innovative Solutions Provider Serving, Pharmaceutical, Nutrition, Agrochemical, Consumer And Industrial Customers With Our Customized Products And Solutions That Are Innovative, Cost-Effective And Conforming To Excellent Quality Standards. With Our Customers At The Heart Of Everything We Do, Our Focus Is To Manufacture Products With Sustainability Using Our Process Technology Through Greater R&D And Engineering Capabilities To Deliver Values For Our Customers For Their Complex And Multi-Step Synthesis Projects.
                                        </p>
										
                                       
                                       <!-- <div class="btn-box">
                                            <a class="btn-1 btn-1 move-section" href="#start"><span>Contact Us</span></a>
                                        </div>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					
                </div>
				
				
		
		<!--<section class="p-5 teams2">
		<div class="teams">
		<div class="container">
		<div class="row">
		
		
		<div class="col-lg-12 ">
		<div class="text-center">
			<h3>Our Leadership Team</h3>
		</div>
		</div>
		
		<div class="col-md-12">
		<div class="leaderName">
		<div class="row justify-content-cente">
		<!--------------------
		<div class="col-lg-3">
		<div class="leads">
		<h4>Dr. P.K. Verma</h4>
		</div>
		</div>
		<!-------------------->
		
		<!--------------------
		<div class="col-lg-3">
		<div class="leads">
		<h4>Saurabh Singh</h4>
		</div>
		</div>
		<!-------------------->
		
		<!--------------------
		<div class="col-lg-3">
		<div class="leads">
		<h4>Harendra Singh</h4>
		</div>
		</div>
		<!-------------------->
		
		
		
		
		<!--------------------
		<div class="col-lg-3">
		<div class="leads">
		<h4>Shashank Khare</h4>
		</div>
		</div>
		<!--------------------
		
		</div>
		</div>
		</div>
		
		
		</div>
		</div>
		</div>
		</section>-->
		
		
		<!-- :: Provide -->
    <!--:: Provide 3 -->
   
	
	
	
	 
 
        
                    <!---<div class="col-md-6 col-lg-3">
                        <div class="team-box">
                            <div class="img-box">
                                <img class="img-fluid" src="img/team/saurabh.jpg" alt="02 team">
                                </div>
                            <div class="text-box text-center">
                                <h5><a href="#">Saurabh Singh</a></h5><br>
                                  <h6>(Director)</h6>
                               
                            </div>
                        </div>
                    </div>-->
                    
					
					 <!--<div class="col-md-6 col-lg-3">
                        <div class="team-box">
                            <div class="img-box">
                                <img class="img-fluid" src="img/team/shanku.jpg" alt="04 team">
                                </div>
                            <div class="text-box text-center">
                                <h5><a href="#">Shashank Khare</a></h5><br> 
                                <h6>(Director)</h6>
                                
                            </div>
                        </div>
                    </div>--->
					
                </div>
            </div>
        </section>
	

	
	
	
	
	
	
	
	
	
	
	  <!-- 
        <section class="testimonial py-100">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 offset-md-1">
                        <div class="testimonial-carousel owl-carousel owl-theme">
                            <div class="item-box">
                                <div class="text-box">Highly recommended &amp; a great experience. The process was simple and easy to understand. Trading was straight forward, the entire process was super smooth!</div>
                                <div class="item-name text-center">
                                    <i class="ar-icons-right-quote"></i>
                                    <h5>Osama Bakri</h5>
                                    <span>NiftyTheme Agency</span>
                                </div>
                            </div>
                            <div class="item-box">
                                <div class="text-box">Highly recommended &amp; a great experience. The process was simple and easy to understand. Trading was straight forward, the entire process was super smooth!</div>
                                <div class="item-name text-center">
                                    <i class="ar-icons-right-quote"></i>
                                    <h5>Nour Ramadan</h5>
                                    <span>AR-Coder Agency</span>
                                </div>
                            </div>
                            <div class="item-box">
                                <div class="text-box">Highly recommended &amp; a great experience. The process was simple and easy to understand. Trading was straight forward, the entire process was super smooth!</div>
                                <div class="item-name text-center">
                                    <i class="ar-icons-right-quote"></i>
                                    <h5>Amina Taha</h5>
                                    <span>Founder &amp; CEO</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>:: Testimonial -->
        
        
       
        
		
        
 <?php include('inc/footer.php');?>       
  
       
        
        <!-- :: JavaScript Files -->
        <!-- :: jQuery JS -->
        <script src="assets/js/jquery-3.6.0.min.js"></script>

        <!-- :: Bootstrap JS Bundle With Popper JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        
        <!-- :: Owl Carousel JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        
        <!-- :: Lity -->
        <script src="assets/js/lity.min.js"></script>
        
        <!-- :: Nice Select -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        
        <!-- :: Waypoints -->
        <script src="assets/js/jquery.waypoints.min.js"></script>

        <!-- :: CounterUp -->
        <script src="assets/js/jquery.counterup.min.js"></script>
        
        <!-- :: Magnific Popup -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		
		<!-- :: MixitUp -->
        <script src="assets/js/mixitup.min.js"></script>
        
        <!-- :: Main JS -->
        <script src="assets/js/main.js"></script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>               
                
            </div>
			
			
			<!--
			<div class="Cont_ent">
			<div class="container">
			<div class="cont_boz">
				<p>One of the leading manufactures of bromine based and lithium based speciality chemicals </p>
				</div>
				</div>
				</div>--->
        </section>
        
        <!-- :: Features -->
        <section class="features">
            <div class="container">
                <div class="row all-features-item">
                    <div class="col-lg-4 padding-0">
                        <div class="features-item one">
							<img src="img/envir.png">
                            <div class="content-box">
                                <h4>Environment, Health & Safety</h4>
                                <p>We are committed to environmental stewardship across the value chain. </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 padding-0">
                        <div class="features-item two active-bg">
                            <img src="img/economy.png">
                            <div class="content-box">
                                <h4>Economic Responsibility</h4>
                                <p>We believe in building our economic success by promoting sustainable.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 padding-0">
                        <div class="features-item three">
                            <img src="img/social.png">
                            <div class="content-box">
                                <h4>Social Responsibilities</h4>
                                <p>Health- and safety-conscious actions are part of all our business processes.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		
		
 
		
	
<!-- :: Services -->
        <section class="services home-2 home-3 py-100-70">
			<div class="container">
				<div class="sec-title home-3 home-3">
                    <div class="row">
                        <div class="col-lg-12">
                        <div class="text-center">
                            
    </body>

</html>