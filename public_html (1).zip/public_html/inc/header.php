<!-- :: All Navbar -->
<header class="all-navbar home-2">
    <head>
        <link rel="icon" href="favicon.ico"/>
    </head>
    

<!-- :: Top Navbar -->
<div class="top-navbar">
<div class="container">
<div class="content-box d-flex align-items-center justify-content-between">
<ul class="website-info">
<li>
<i class="far fa-envelope"></i>
<a href="mailto:info@onsindustries.com">info@onsindustries.com</a>
</li>
<!--<li>
<i class="ar-icons-phone"></i>
<a href="tel:+91 9315926696">+91 9315926696</a>
</li>-->
<li>
<i class="ar-icons-phone"></i>
<a href="tel:+91 9315926696">+91 9315926696</a>
</li>
</ul>
<ul class="website-icon-social">
<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
<li><a href="#"><i class="fab fa-twitter"></i></a></li>
<li><a href="#"><i class="fas fa-rss"></i></a></li>
<li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
</ul>
</div>
</div>
</div>

<!-- :: Navbar -->
<nav class="nav-bar">
<div class="container">
<div class="content-box d-flex align-items-center justify-content-between">
<div class="demo logo">
<a href="index.php" class="demo logo-nav">
<img class="img-fluid one" src="img/demo logo.jpg" alt="Logo">
<img class="img-fluid two" src="img/demo logo.jpg" alt="Logo">
</a>
<a href="#open-nav-bar-menu" class="open-nav-bar">
<span></span>
<span></span>
<span></span>
</a>
</div>
<div class="nav-bar-links" id="open-nav-bar-menu">
<ul class="level-1">
<li class="item-level-1 ">
<a href="index.php" class="link-level-1 color-active">Home</a>
</li>
<li class="item-level-1 ">
<a href="Team.php" class="link-level-1">Team & Profile</a>

</li>
<li class="item-level-1 ">
<a href="about.php" class="link-level-1">About Us</a>





</li>

<li class="item-level-1 ">
<a href="product.php" class="link-level-1">Products</a>

</li>

<li class="item-level-1 has-menu">
<a href="#" class="link-level-1">Company Policy</a>
<ul class="level-2">
<li class="item-level-2">
<a class="link-level-2" href="quality-policy.php">Quality policy</a>
</li>
<li class="item-level-2">
<a class="link-level-2" href="environment-health-safety.php">Environment, Health & Safety</a>
</li>
<li class="item-level-2">
<a class="link-level-2" href="sustainability.php">Sustainability</a>
</li>
<li class="item-level-2">
<a class="link-level-2" href="values.php">Values</a>
</li>

<li class="item-level-2">
<a class="link-level-2" href="economic-responsibility.php#economic">Economic Responsibility</a>
</li>

<li class="item-level-2">
<a class="link-level-2" href="economic-responsibility.php#social">Social Responsibilities</a>
</li>


</ul>
</li>
<li class="item-level-1 ">
<a href="manufacturing-infrastructure.php" class="link-level-1">Infrastructure</a>


<!--<li class="item-level-2">
<a class="link-level-2" href="manufacturing-infrastructure.php#manufacturing-capaciy">Manufacturing Capacity</a>
</li>

<li class="item-level-2">
<a class="link-level-2" href="manufacturing-infrastructure.php#utilities">Utilities</a>
</li>

<li class="item-level-2">
<a class="link-level-2" href="manufacturing-infrastructure.php#equipment">Equipment &amp; Capacity</a>
</li>--->

</li>

<li class="item-level-1">
<a href="career.php" class="link-level-1">Career</a>
</li>


<li class="item-level-1 Cont_act_hide">
<a href="contact.php" class="link-level-1">Contact Us</a>
</li>




</ul>
</div>
<link rel="icon" href="favicon.ico"/>
<ul class="nav-bar-tools d-flex align-items-center justify-content-between">

<li class="item buttons">
<a class="btn-1 btn-3" href="contact.php"><span>Contact Us</span></a>
</li>
</ul>
</div>
</div>
</nav>
</header>


