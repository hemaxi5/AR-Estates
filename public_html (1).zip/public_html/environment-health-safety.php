<!doctype html>
<html lang="en">
    

<head>
        <!-- :: Required Meta Tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="ONS Industries">
        <meta name="keywords" content="ONS Industries">

        <!-- :: Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- :: Favicon -->
        <link rel="icon" type="image/png" href="assets/images/favicon.png">

        <!-- :: Title -->
        <title>Environment, Health & Safety | ONS Industries</title>

        <!-- :: Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&amp;family=Heebo:wght@400;500;600;700&amp;display=swap">

        <!-- :: Fontawesome -->
        <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">

        <!-- :: Flaticon -->
        <link rel="stylesheet" href="assets/fonts/flaticon/style.css">

        <!-- :: Animate -->
        <link rel="stylesheet" href="assets/css/animate.css">
        
        <!-- :: Owl Carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        
        <!-- :: Lity -->
        <link rel="stylesheet" href="assets/css/lity.min.css">
        
        <!-- :: Nice Select CSS -->
        <link rel="stylesheet" href="assets/css/nice-select.css">
        
        <!-- :: Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/magnific-popup.css">

        <!-- :: Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- :: Style Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <!--[if lt IE 9]>
                <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
                <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
            <![endif]-->
    </head>

    <body>

 <!------------
        <div class="loading">
            <div class="loading-box">
                <div class="lds-roller">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
		-------------->
        
	<?php include('inc/header.php');?>  
        

 
        <!-- :: Breadcrumb Header -->
        <section class="breadcrumb-header style-2" id="page" style="background-image: url(img/banner/banner-chemical-industry.jpg)">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="banner">
                            <h1>Environment, Health & Safety</h1>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><i class="fas fa-angle-right"></i></li>
                                <li>Environment, Health & Safety</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		



 <!-- :: Team -->
       
		<section class="about-us home-3 py-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="about-us-img-box">
                            <div class="img-box" style="background-image: url(img/env.jpg)"></div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-us-text-box">
                            <div class="sec-title home-3">
                                <div class="policy">
								<h4> Environment</h4>
								<ul class="policy1">
								<li> We are committed to environmental stewardship across the value chain. We keep wastes to the minimum and clean gases and effluents scientifically.
								<br>
								<br>
								We strive to reduce organic & inorganic waste generation in the process at the R&D stage itself. At the plant level we carry-out extensive studies for each product and at pilot plant level to understand the waste generation for treatment and corrective action.
								</li>
								</ul>
								
								
								<h4> Health</h4>
								<ul class="policy1">
								<li> Employees are our biggest asset and their health is of vital importance to us. We follow best practices to maintain our manufacturing plants free of volatile organic compounds, free from dust and odours
								<br>
								<br>
								All employees undergo periodic medical check-ups by another agency and while those exposed to chemicals/dust undergo special tests. A First aid medical facility is available on sight.
								</li>
								</ul>
								
								
								<h4> Safety</h4>
								<ul class="policy1">
								<li>The key processes comprise regular safety surveillance, inspections and audits, permit to work system for operational/maintenance safety, fire prevention and protection activities, Monthly reports address EHS initiatives, compliance and various records under statutory requirements, training of employees, interaction with associations of adjacent communities, and observance or celebration of National Safety Day, National Fire Safety Day to promote EHS awareness amongst employees
								</li>
								</ul>
								
								
								</div>
                            </div>
							
							
                        </div>
                    </div>
                </div>
            </div>
        </section>
		
  
  	<?php include('inc/footer.php');?> 
        
        <!-- :: JavaScript Files -->
        <!-- :: jQuery JS -->
        <script src="assets/js/jquery-3.6.0.min.js"></script>

        <!-- :: Bootstrap JS Bundle With Popper JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        
        <!-- :: Owl Carousel JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        
        <!-- :: Lity -->
        <script src="assets/js/lity.min.js"></script>
        
        <!-- :: Nice Select -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        
        <!-- :: Waypoints -->
        <script src="assets/js/jquery.waypoints.min.js"></script>

        <!-- :: CounterUp -->
        <script src="assets/js/jquery.counterup.min.js"></script>
        
        <!-- :: Magnific Popup -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		
		<!-- :: MixitUp -->
        <script src="assets/js/mixitup.min.js"></script>
        
        <!-- :: Main JS -->
        <script src="assets/js/main.js"></script>
    </body>


</html>