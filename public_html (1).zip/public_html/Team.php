<!doctype html>
<html lang="en">
    

<head>
        <!-- :: Required Meta Tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="ONS Industries">
        <meta name="keywords" content="ONS Industries">

        <!-- :: Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- :: Favicon -->
        <link rel="icon" type="image/png" href="assets/images/favicon.png">

        <!-- :: Title -->
        <title>Team & Profile | ONS Industries</title>

        <!-- :: Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&amp;family=Heebo:wght@400;500;600;700&amp;display=swap">

        <!-- :: Fontawesome -->
        <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">

        <!-- :: Flaticon -->
        <link rel="stylesheet" href="assets/fonts/flaticon/style.css">

        <!-- :: Animate -->
        <link rel="stylesheet" href="assets/css/animate.css">
        
        <!-- :: Owl Carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        
        <!-- :: Lity -->
        <link rel="stylesheet" href="assets/css/lity.min.css">
        
        <!-- :: Nice Select CSS -->
        <link rel="stylesheet" href="assets/css/nice-select.css">
        
        <!-- :: Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/magnific-popup.css">

        <!-- :: Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- :: Style Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <!--[if lt IE 9]>
                <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
                <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
            <![endif]-->
    </head>

    <body>

 <!------------
        <div class="loading">
            <div class="loading-box">
                <div class="lds-roller">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
		-------------->
        
	<?php include('inc/header.php');?>  
        

 
        <!-- :: Breadcrumb Header -->
        <section class="breadcrumb-header style-2" id="page" style="background-image: url(img/banner/banner-chemical-industry.jpg)">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="banner">
                            <h1>Team & Profile</h1>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><i class="fas fa-angle-right"></i></li>
                                <li>Team & Profile</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		
		<section class="conta">
		    <div class="container">
		        <div class="row">
		            <div class="col-sm-12">
		                <div class="contact-des">
		                    <div class="tei">
		                         <h3> Mr. Harendra Singh<br><h4>(Business & SCM Head)</h4> </h3>
		                        
		                    </div>
		                    <div class="desr">
		                        <p>Becoming isn’t about arriving somewhere or achieving a certain aim. I see it instead as forward motion, a means of evolving, a way to reach continuously toward a better self. The journey doesn’t end. Having up to 20 years of experience in supply chain and marketing makes me a completely experienced for handling business. I have master’s degree in field of MBA (Supply Chain and Management) which also makes me a compatible person in handling my company growth….</p>
                                   <div class="box">
                                   
                                </div>
                                   <div class="box">
                                    
                                </div> 
		                        
		                    </div>
		                </div>
		                <div class="contact-des">
		                    <div class="tei">
		                         <h3> Dr. PK Verma <br><h4>(CSO)</h4> </h3>
		                        
		                    </div>
		                    <div class="desr">
		                        <p>
		                        
		                        PHD from HBTI Kanpur, Ex R&D head Jubilant Ingrevia having more than 35 years of experience in R&D, project management and new product development in API, Agro and fine chemical industries. Dr. Verma is first to develop and commercialize continuous vapour phase ammoxidation catalyst in the country to manufacture cyanopyridine from picolines. Dr. Verma developed and commercialize many fixed and fluidized bed catalytic processes for manufacturing fine chemicals, drug intermediates and Agro intermediates. He received national awards in 1996, 2004 and 2006 for these achievements. Received Acharya PC ray and many more awards for contributions to chemical industry
						</p>
                                   
                                <div class="box">
                                    
                                </div> 
		                        
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
		    
		</section>
		
		    <div class="container">
		        <div class="row">
		            <div class="col-sm-12">
		                <div class="contact-des">
		                    <div class="tei">
		                         <h3> Dr. Chetan R Dubey<br><h4>(Chief R&D Head)</h4> </h3>
		                        
		                    </div>
		                    <div class="desr">
		                        <p>Dr. Chetan R Dubey having skilled and experienced Organic Chemist with in-depth subject knowledge, leading a team of experienced chemists dedicated to Process Development, Synthesis of Agro & Pharma Intermediates and Novel Route Scouting for target molecules. Research experience in Synthetic Organic Chemistry, Process Development, Medicinal Chemistry as well as natural products isolation & characterization using modern scientific tools and techniques.</p>
                                   
                                   
                                </div>
                                   
                                    
                                </div> 
		                        
		                    </div>
		                </div>
		                <br>
		                <br>
		<!-- :: contact us -->
		
		
  
  	<?php include('inc/footer.php');?> 
        
        <!-- :: JavaScript Files -->
        <!-- :: jQuery JS -->
        <script src="assets/js/jquery-3.6.0.min.js"></script>

        <!-- :: Bootstrap JS Bundle With Popper JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        
        <!-- :: Owl Carousel JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        
        <!-- :: Lity -->
        <script src="assets/js/lity.min.js"></script>
        
        <!-- :: Nice Select -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        
        <!-- :: Waypoints -->
        <script src="assets/js/jquery.waypoints.min.js"></script>

        <!-- :: CounterUp -->
        <script src="assets/js/jquery.counterup.min.js"></script>
        
        <!-- :: Magnific Popup -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		
		<!-- :: MixitUp -->
        <script src="assets/js/mixitup.min.js"></script>
        
        <!-- :: Main JS -->
        <script src="assets/js/main.js"></script>
    </body>


</html>